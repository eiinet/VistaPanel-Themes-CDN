<?php defined("APP") or die() ?>
<section<?php echo Main::body_class() ?>>
  <div class="container">
  	<div class="is404">
			<?php echo $content ?>
  	</div>
  </div>
</section>